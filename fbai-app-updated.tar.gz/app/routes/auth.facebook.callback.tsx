import type { LoaderFunctionArgs } from "@remix-run/node";
import { json, redirect } from "@remix-run/node";
import { authenticate } from "../shopify.server";
import { db } from "../db.server";
import axios from "axios";

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { session } = await authenticate.admin(request);
  const url = new URL(request.url);
  
  const code = url.searchParams.get("code");
  const state = url.searchParams.get("state");
  const error = url.searchParams.get("error");

  if (error) {
    console.error("Facebook OAuth error:", error);
    return redirect("/app?error=facebook_auth_failed");
  }

  if (!code || !state) {
    return redirect("/app?error=invalid_callback");
  }

  try {
    // Decode state to get shop
    const stateData = JSON.parse(atob(state));
    const shop = stateData.shop;

    if (shop !== session.shop) {
      return redirect("/app?error=invalid_state");
    }

    // Exchange code for access token
    const tokenResponse = await axios.post("https://graph.facebook.com/v18.0/oauth/access_token", {
      client_id: process.env.FACEBOOK_APP_ID,
      client_secret: process.env.FACEBOOK_APP_SECRET,
      redirect_uri: process.env.NODE_ENV === 'development' 
        ? process.env.LOCAL_FACEBOOK_REDIRECT_URI 
        : process.env.FACEBOOK_REDIRECT_URI,
      code: code,
    });

    const { access_token } = tokenResponse.data;

    // Get user info
    const userResponse = await axios.get(`https://graph.facebook.com/v18.0/me`, {
      params: {
        access_token: access_token,
        fields: "id,name,email"
      }
    });

    const userData = userResponse.data;

    // Get business accounts
    let businessId = null;
    let adAccountId = null;
    
    try {
      const businessResponse = await axios.get(`https://graph.facebook.com/v18.0/${userData.id}/businesses`, {
        params: {
          access_token: access_token,
          fields: "id,name"
        }
      });

      if (businessResponse.data.data && businessResponse.data.data.length > 0) {
        businessId = businessResponse.data.data[0].id;

        // Get ad accounts for the business
        const adAccountsResponse = await axios.get(`https://graph.facebook.com/v18.0/${businessId}/owned_ad_accounts`, {
          params: {
            access_token: access_token,
            fields: "id,name,account_status"
          }
        });

        if (adAccountsResponse.data.data && adAccountsResponse.data.data.length > 0) {
          // Find an active ad account
          const activeAccount = adAccountsResponse.data.data.find((acc: any) => acc.account_status === 1);
          adAccountId = activeAccount ? activeAccount.id : adAccountsResponse.data.data[0].id;
        }
      }
    } catch (businessError) {
      console.warn("Could not fetch business/ad account info:", businessError);
    }

    // Store Facebook account in database
    await db.facebookAccount.upsert({
      where: {
        shop_facebookUserId: {
          shop: shop,
          facebookUserId: userData.id
        }
      },
      update: {
        accessToken: access_token,
        businessId: businessId,
        adAccountId: adAccountId,
        isActive: true,
        updatedAt: new Date()
      },
      create: {
        shop: shop,
        facebookUserId: userData.id,
        accessToken: access_token,
        businessId: businessId,
        adAccountId: adAccountId,
        isActive: true
      }
    });

    return redirect("/app?success=facebook_connected");

  } catch (error) {
    console.error("Facebook OAuth callback error:", error);
    return redirect("/app?error=facebook_auth_failed");
  }
};
-- AlterTable
ALTER TABLE "Campaign" ADD COLUMN "adAccountId" TEXT;
ALTER TABLE "Campaign" ADD COLUMN "currency" TEXT;
